#include "myForm.h"

myForm::myForm(QWidget* parent): QWidget(parent)
{
  ui.setupUi(this);
}
